package com.galaxy.exceptions;

public class RuleViolationException extends Exception {

	public RuleViolationException(String message) {
		super(message);
	}

}
